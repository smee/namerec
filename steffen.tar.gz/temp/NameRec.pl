#! /usr/lcal/bin/perl -w
use Time::localtime;
$dir="/var/jobs/daily/NameRec-de";
$today = localtime(time())->yday;  
$year = localtime(time())->year;
$day="$today-$year";
system("rm *-$day.txt");
system("echo $day >$day.started");
system("/opt/java/bin/java -cp $dir:/$dir/gnu.regexp-1.1.4/lib/gnu-regexp-1.1.4.jar:./:$dir/gnu.regexp-1.1.4/lib/mm.mysql-2.0.8-bin.jar Recognizer -ic $dir/klassNamen.txt -ir $dir/regexps.txt -ik $dir/wissenAkt.txt -rl $dir/pats2.txt -rp $dir/patPers.txt -pt 0.09 -oi $dir/items-$day.txt -om $dir/maybes-$day.txt -og $dir/NEs-$day.txt -or $dir/contexts-$day.txt >$dir/run-$day.log");
#system("/usr/local/bin/java -cp /var/home/cbiemann/NameRecAkt:/var/home/cbiemann/gnu.regexp-1.1.4/lib/gnu-regexp-1.1.4.jar:./:/var/home/cbiemann/gnu.regexp-1.1.4/lib/mm.mysql-2.0.8-bin.jar Recognizer -ic /var/home/cbiemann/NameRecAkt/klassNamen.txt -ir /var/home/cbiemann/NameRecAkt/regexps.txt -ik /var/home/cbiemann/NameRecAkt/wissenAkt.txt -rl /var/home/cbiemann/NameRecAkt/pats2.txt -rp /var/home/cbiemann/NameRecAkt/patPers.txt -pt 0.09 -oi /var/home/cbiemann/NameRecAkt/items-$day.txt -om /var/home/cbiemann/NameRecAkt/maybes-$day.txt -og /var/home/cbiemann/NameRecAkt/NEs-$day.txt -or /var/home/cbiemann/NameRecAkt/contexts-$day.txt >/var/home/cbiemann/NameRecAkt/run-$day.log");
exit(1);
